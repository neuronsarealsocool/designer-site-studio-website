Designer Site Studio

17 public working prompt packs and their linked asset maps. The 169 media and support files remain hosted separately; this bundle contains their direct URLs, sizes and SHA-256 hashes. Private backup documents are excluded. Required notices accompany the relevant packs. No new rights to third-party media are granted.

Use with Codex, Claude or your coding agent. Reuse prompts as written, adapt them or combine ideas. WordPress is optional; Replicate is the default for new media. Review new media in chat before publication.
